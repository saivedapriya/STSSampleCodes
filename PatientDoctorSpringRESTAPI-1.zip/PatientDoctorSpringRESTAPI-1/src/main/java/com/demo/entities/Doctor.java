package com.demo.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
//import javax.validation.constraints.NotNull;


@Entity
public class Doctor {

	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int DoctorId;
	
	//@NotNull
	private String Doctor_first_name;
	
	private String Doctor_last_name;
	
	private double Doctor_phone_number;

	public Doctor() {
		super();
	}

	public int getDoctorId() {
		return DoctorId;
	}

	public void setDoctorId(int doctorId) {
		DoctorId = doctorId;
	}

	public String getDoctor_first_name() {
		return Doctor_first_name;
	}

	public void setDoctor_first_name(String doctor_first_name) {
		Doctor_first_name = doctor_first_name;
	}

	public String getDoctor_last_name() {
		return Doctor_last_name;
	}

	public void setDoctor_last_name(String doctor_last_name) {
		Doctor_last_name = doctor_last_name;
	}

	public double getDoctor_phone_number() {
		return Doctor_phone_number;
	}

	public void setDoctor_phone_number(double doctor_phone_number) {
		Doctor_phone_number = doctor_phone_number;
	}

}