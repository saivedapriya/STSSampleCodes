package com.demo.entities;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

@Entity
public class Appointment {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int apponitment_id;
	
	private int patient_id;
	
	private int doctor_id;
	
	//private DATE appintment_date;
	
	private String appointment_reason;
	
	@OneToOne(targetEntity = Patient.class,cascade = CascadeType.ALL)
    @NotFound(action = NotFoundAction.IGNORE)
    @JoinColumn(name = "Rid_Fk")
    private Patient patient;
	
	@OneToOne(targetEntity = Doctor.class,cascade = CascadeType.ALL)
    @JoinColumn(name = "Rid_Fkk")
    private Doctor doctor;

	public Appointment() {
		super();
	}

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	public Doctor getDoctor() {
		return doctor;
	}

	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}

	public int getApponitment_id() {
		return apponitment_id;
	}

	public void setApponitment_id(int apponitment_id) {
		this.apponitment_id = apponitment_id;
	}

	public int getPatient_id() {
		return patient_id;
	}

	public void setPatient_id(int patient_id) {
		this.patient_id = patient_id;
	}

	public int getDoctor_id() {
		return doctor_id;
	}

	public void setDoctor_id(int doctor_id) {
		this.doctor_id = doctor_id;
	}


	/*
	 * public DATE getAppintment_date() { return appintment_date; }
	 * 
	 * 
	 * public void setAppintment_date(DATE appintment_date) { this.appintment_date =
	 * appintment_date; }
	 * 
	 * */
	
	  public String getAppointment_reason() { return appointment_reason; }
	  
	  public void setAppointment_reason(String appointment_reason) {
	  this.appointment_reason = appointment_reason; }
	 
	
	
	
}
