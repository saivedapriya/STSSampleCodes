package com.demo.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
//import javax.validation.constraints.NotNull;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;


@Entity
@NamedQueries(value = {
        @NamedQuery(name = "Patient.findbyAge",query = "SELECT p FROM Patient p WHERE p.age=?1")
})
public class Patient {

	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int PatientId;
	
	//@NotNull
	private String first_name;
	
	private String last_name;
	
	private double phone_number;

	public Patient() {
		super();
	}

	public int getPatientId() {
		return PatientId;
	}

	public void setPatientId(int patientId) {
		PatientId = patientId;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public double getPhone_number() {
		return phone_number;
	}

	public void setPhone_number(double phone_number) {
		this.phone_number = phone_number;
	}

	}
