package com.demo.controllers;

import java.util.List;

import javax.persistence.criteria.Join;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.demo.entities.Appointment;
import com.demo.repositories.AppointmentRepository;


public class AppointmentController {

	@Autowired
	private AppointmentRepository apprepo;
	
	@GetMapping("/getR/{appointment_reason}")
    public ResponseEntity<List<Appointment>> getRtest(@PathVariable String appointment_reason) {
        return new ResponseEntity<>(apprepo.getRtest(appointment_reason), HttpStatus.OK);
    }
	
	@GetMapping("/l")
    public List<Join> fetchLeftJoin(){ return apprepo.fetchLeftJoin(); }
    @GetMapping("/r")
    public List<Join> fetchRightJoin(){ return apprepo.fetchRightJoin(); }
    @GetMapping("/i")
    public List<Join> fetchInnerJoin(){ return apprepo.fetchInnerJoin(); }
    @GetMapping("/c")
    public List<Join> fetchCrossJoin(){ return apprepo.fetchCrossJoin(); }
}
