package com.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.demo.entities.Patient;
import com.demo.repositories.PatientRepository;
import com.demo.services.PatientService;



@RestController
public class PatientController {

	@Autowired
    private PatientService service;
	@Autowired
    private PatientRepository patientRepository;
	
	@PostMapping("/addP")
    public List<Patient> addPatients(@RequestBody List<Patient> patients){
        return service.addPatients(patients);
    }
	@GetMapping("/getP")
    public List<Patient> getPatients(){ return service.getPatients(); 
    }
	@GetMapping("/getPById/{id}")
    public Patient getPatientById(@PathVariable int id){ 
		return service.getPatientById(id); 
		}
	
	@GetMapping("/getP/{name}/{age}")
    public List<Patient> findbyName(@PathVariable String name,
                                    @PathVariable Integer age){
        return patientRepository.findbyName(name,age);
	}
	@PutMapping("/updateP")
    public Patient updatePatient(@RequestBody Patient patient){
        return service.updatePatient(patient);
    }
	
	@DeleteMapping("/deleteP/{id}")
    public String deletePatient(@PathVariable int id){ 
		return service.deletePatient(id); 
		}
}
