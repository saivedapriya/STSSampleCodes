package com.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.demo.entities.Doctor;
import com.demo.repositories.DoctorRepository;
import com.demo.services.DoctorService;

public class DoctorController {

	@Autowired
    private DoctorService doctorservice;
	@Autowired
	private DoctorRepository doctorrepository;
	
	@PostMapping("/addD")
    public List<Doctor> addDoctors(@RequestBody List<Doctor> doctors){
        return doctorservice.addDoctors(doctors);
    }
	
	@GetMapping("/getD")
    public List<Doctor> getDoctors()
	{ 
		return doctorservice.getDoctors(); 
    }
	
	@GetMapping("/getDById/{id}")
    public Doctor getDoctorById(@PathVariable int id)
	{ 
		return doctorservice.getDoctorById(id); 
    }
	
	@PutMapping("/updateD")
    public Doctor updateDoctor(@RequestBody Doctor doctor){
        return doctorservice.updatedoctor(doctor);
    }
	@DeleteMapping("/deleteD/{id}")
    public String deleteDoctor(@PathVariable int id){
        return doctorservice.deleteDoctor(id);
    }
	
	
}
