package com.demo.repositories;

import java.util.List;

import javax.persistence.criteria.Join;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.demo.entities.Appointment;



@Repository
public interface AppointmentRepository extends JpaRepository<Appointment, Integer>{

	 // Get all details of specified test
    @Query("SELECT a from appointment a where a.apponitment_id=?1")
    public List<Appointment> getRtest(String appointment_reason);
    // Get values from Combination of Entities
   /* @Query("SELECT new com.demo.entities.Join(a.apponitment_id, a.patient_id, a.doctor_id, p.PatientId, p.first_name,p.last_name, p.phone_number) " +
            "FROM appointment a JOIN a.patient p JOIN a.doctor d")
    public List<AppResponse> getJoinInformation(); */


    // Joins
    @Query("SELECT new com.demo.entities.Join(a.apponitment_id, a.patient_id, a.doctor_id, p.PatientId, p.first_name,p.last_name, p.phone_number) "
            + "FROM appointment a LEFT JOIN a.patient p")
    List<Join> fetchLeftJoin();

    @Query("SELECT a.apponitment_id, a.patient_id, a.doctor_id, p.PatientId, p.first_name,p.last_name, p.phone_number" + "FROM Report r RIGHT JOIN r.patient p")
    List<Join> fetchRightJoin();

    @Query("SELECT new com.demo.entities.Join(a.apponitment_id, a.patient_id, a.doctor_id, p.PatientId, p.first_name,p.last_name, p.phone_number) "
            + "FROM Report r INNER JOIN r.patient p")
    List<Join> fetchInnerJoin();

    @Query("SELECT new com.demo.entities.Join(a.apponitment_id, a.patient_id, a.doctor_id, p.PatientId, p.first_name,p.last_name, p.phone_number) "
            + "FROM Report r, Patient p")
    List<Join> fetchCrossJoin();
	
}
