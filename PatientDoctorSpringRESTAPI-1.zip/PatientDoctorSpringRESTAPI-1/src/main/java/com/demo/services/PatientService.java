package com.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.entities.Patient;
import com.demo.repositories.PatientRepository;

@Service
public class PatientService {

	@Autowired
	private PatientRepository patrepo;
	
	 public List<Patient> addPatients(List<Patient> patients){
		 return patrepo.saveAll(patients); 
		 }
	 
	    public List<Patient> getPatients(){
	        return patrepo.findAll();
	    }
	    public Patient getPatientById(int id){ 
	    return patrepo.findById(id).orElse(null); 
	    }
	    
	    public Patient updatePatient(Patient patient){
	        Patient existingProduct=patrepo.findById(patient.getPatientId()).orElse(null);
	        existingProduct.setFirst_name(patient.getFirst_name());
	        existingProduct.setLast_name(patient.getLast_name());
	        return patrepo.save(existingProduct);
	    }
	    public String deletePatient(int id){
	    	patrepo.deleteById(id);
	        return "Removed Report with ID - " + id;
	    }
}
