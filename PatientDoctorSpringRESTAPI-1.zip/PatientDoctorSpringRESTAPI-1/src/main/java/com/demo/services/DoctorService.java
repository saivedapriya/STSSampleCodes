package com.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.demo.entities.Doctor;
import com.demo.entities.Patient;
import com.demo.repositories.DoctorRepository;


public class DoctorService {

	 @Autowired
	    private DoctorRepository doctorrepository;
	 
	 public List<Doctor> addDoctors(List<Doctor> doctors){ 
		 return doctorrepository.saveAll(doctors); 
		 }
	 
	 public List<Doctor> getDoctors(){
	        return doctorrepository.findAll();
	    }
	 
	 public Doctor getDoctorById(int id){ 
		return doctorrepository.findById(id).orElse(null); 
		}
	 
	 public Doctor updatedoctor(Doctor doctor){
	        Doctor existingProduct=doctorrepository.findById(doctor.getDoctorId()).orElse(null);
	        existingProduct.setDoctor_first_name(doctor.getDoctor_first_name());
	        existingProduct.setDoctor_last_name(doctor.getDoctor_last_name());
	        existingProduct.setDoctor_phone_number(doctor.getDoctor_phone_number());
	        return doctorrepository.save(existingProduct);
	    }
	 
	 public String deleteDoctor(int id){
	    doctorrepository.deleteById(id);
	        return "Removed Doctor with ID - " + id;
	    }
	    
}
