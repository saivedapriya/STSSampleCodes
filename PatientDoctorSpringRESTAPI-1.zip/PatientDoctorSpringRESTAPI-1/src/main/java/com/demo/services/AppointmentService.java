package com.demo.services;

import java.util.List;

import javax.persistence.criteria.Join;

import org.springframework.beans.factory.annotation.Autowired;

import com.demo.entities.Appointment;
import com.demo.repositories.AppointmentRepository;

public class AppointmentService {

	@Autowired
	private AppointmentRepository apprepo;
	
	public List<Appointment> getRtest(String test) { 
		return apprepo.getRtest(test); 
		}



    public List<Join> getLeftJoin() {
        List<Join> list = apprepo.fetchLeftJoin();
        list.forEach(l -> System.out.println(l));
        return list;
    }

    public List<Join> getRightJoin() {
        List<Join> list = apprepo.fetchRightJoin();
        list.forEach(l -> System.out.println(l));
        return list;
    }

    public List<Join> getInnerJoin() {
        List<Join> list = apprepo.fetchInnerJoin();
        list.forEach(l -> System.out.println(l));
        return list;
    }

    public List<Join> getCrossJoin() {
        List<Join> list = apprepo.fetchCrossJoin();
        list.forEach(l -> System.out.println(l));
        return list;
    }
    
	
    
    
}
